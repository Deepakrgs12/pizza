package pizza;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class login1 {

	
		Connection c;
		PreparedStatement ps;
		ResultSet rs;

			public login1() {
				// TODO Auto-generated constructor stub
				try{  Class.forName("oracle.jdbc.driver.OracleDriver"); 
				c =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","deepak","deepak");

			
				}
				catch(Exception e)
				{System.out.println(e);}
			}

			public String getlogin(String userid, String pass) {
				// TODO Auto-generated method stub
				String Username=null;
				try {
					ps=c.prepareStatement("select firstname from reg where email=? and Password=?");
					ps.setString(1,userid);
					ps.setString(2,pass);
					rs=ps.executeQuery();
					if(rs.next())
					{
						Username=rs.getString(1);
						
					}
				}
				catch(Exception e)
				{System.out.println(e);}
				return Username;

			}

			

			
			}

