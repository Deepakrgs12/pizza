package pizza;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class signup
 */
public class signup extends HttpServlet {
	private static final long serialVersionUID = 1L;

	Connection c;
	PreparedStatement ps;
	ResultSet rs;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public signup() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=response.getWriter();
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String email=request.getParameter("email");
		String pass=request.getParameter("pass");
		String dob=request.getParameter("dob");
		String phone=request.getParameter("phone");
		String address=request.getParameter("add");
		
		
		try{  Class.forName("oracle.jdbc.driver.OracleDriver"); 
		c =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","deepak","deepak");
		
		Statement stmt=c.createStatement();
		
		stmt.executeUpdate("insert into reg values('"+fname+"','"+lname+"','"+email+"','"+pass+"','"+dob+"','"+phone+"','"+address+"')");
		response.sendRedirect("regcom.html"); 
		
		//out.println("you are registered");
	
		}
		catch(Exception e)
		{System.out.println(e);}
	}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
