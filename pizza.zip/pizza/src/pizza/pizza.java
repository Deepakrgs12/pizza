package pizza;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Servlet implementation class pizza
 */
public class pizza extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	HttpSession Session=request.getSession();
		PrintWriter out=response.getWriter();
		String userid=request.getParameter("email");
	//	Session.setAttribute("name",userid);
				String pass=request.getParameter("pass");
				
				
				 HttpSession session=request.getSession();
			      session.setAttribute("uname",userid);
			    //  session.setAttribute("upass",pass);
				
				
				login1 l =new login1();
				String username=l.getlogin(userid,pass);
				if(username==null)
				{
					
					//response.sendRedirect("afterlogin.html"); 
				//	out.println("default.html");
					response.sendRedirect("wrongpass.html"); 
				}
				else {
					
					response.sendRedirect("afterlogin.html"); 
					//out.println("hello"+username);
				}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
