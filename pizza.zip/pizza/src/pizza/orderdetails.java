package pizza;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class orderdetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection c;
		PreparedStatement ps;
		ResultSet rs;
		PrintWriter out=response.getWriter();
		try{  Class.forName("oracle.jdbc.driver.OracleDriver"); 
		c =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","deepak","deepak");

		ps=c.prepareStatement("select * from order3");
		rs=ps.executeQuery();
		out.println("<html class=\"no-js\"> <!--<![endif]-->\r\n" + 
				"<head>\r\n" + 
				"    <title>A.D King</title>\r\n" + 
				"\r\n" + 
				"</style>\r\n" + 
				"   <script>\r\n" + 
				"<!--\r\n" + 
				"function timedRefresh(timeoutPeriod) {\r\n" + 
				"	setTimeout(\"location.reload(true);\",timeoutPeriod);\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				"window.onload = timedRefresh(5000);\r\n" + 
				"\r\n" + 
				"//   -->\r\n" + 
				"</script>\r\n" + 
				"    <!-- meta -->\r\n" + 
				"    <meta charset=\"utf-8\">\r\n" + 
				"    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">\r\n" + 
				"    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no\">\r\n" + 
				"\r\n" + 
				"    <!-- css -->\r\n" + 
				"    <link rel=\"stylesheet\" href=\"css/bootstrap.min.css\">\r\n" + 
				"    <link rel=\"stylesheet\" href=\"css/bootstrap-theme.min.css\">\r\n" + 
				"    <link rel=\"stylesheet\" href=\"css/font-awesome.min.css\">\r\n" + 
				"    <link rel=\"stylesheet\" href=\"css/main.css\">\r\n" + 
				"\r\n" + 
				"    <!-- google font -->\r\n" + 
				"    <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Kreon:300,400,700'>\r\n" + 
				"    \r\n" + 
				"    <!-- js -->\r\n" + 
				"    <script src=\"js/vendor/modernizr-2.6.2-respond-1.1.0.min.js\"></script>\r\n" + 
				"</head>\r\n" + 
				"<body data-spy=\"scroll\" data-target=\"#navbar\" data-offset=\"120\" >\r\n" + 
				"\r\n" + 
				"\r\n" + 
				"\r\n" + 
				"\r\n" + 
				" <div id=\"special-offser\" class=\"parallaxmn pricing\">\r\n" + 
				"  <div class=\"row\">\r\n" + 
				"			   <div class=\"col-md-2 col-sm-2\">\r\n" + 
				"			  <a href=\"index.html\">LOGOUT</a>  </div> </div>\r\n" + 
				"       <div class=\"container inner\">\r\n" + 
				"\r\n" + 
				"          <h2 class=\"section-title text-center\">HERE YOU GET THE LIST OF ALL ORDERED CANDIDATE</h2>\r\n" + 
				"            <p class=\"lead main text-center\">There is no sincerer love than the love of food!</p>\r\n" + 
				"            \r\n" + 
				"           \r\n" + 
				"               \r\n" + 
				"            <div class=\"row\">\r\n" + 
				"			\r\n" + 
				"			  <div class=\"col-md-2 col-sm-2\">\r\n" + 
				"			   </div>\r\n" + 
				"                <div style=\"left margin:100px;\" class=\"col-md-8\">\r\n" + 
				"                   <table border=\"4\">\r\n" + 
				"  <tr>\r\n" + 
				"    <th>E-MAIL</th>\r\n" + 
				"    <th>PIZZA TYPE</th>\r\n" + 
				"    <th>QUANTITY</th>\r\n" + 
				"    <th>DATE AND TIME</th>\r\n" + 
				"  </tr>");
		while(rs.next())
		{
			out.println("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td></tr>");
		}
		out.println("</table>\r\n" + 
				"\r\n" + 
				"   </div>\r\n" + 
				"        </div>\r\n" + 
				"        <!-- /.container --> \r\n" + 
				"    </div><!-- /#special-offser -->\r\n" + 
				"\r\n" + 
				"</div>\r\n" + 
				"</div>\r\n" + 
				"</div>\r\n" + 
				"</div>\r\n" + 
				"<footer id=\"footer\" class=\"dark-wrapper\">\r\n" + 
				"        <section class=\"ss-style-top\"></section>\r\n" + 
				"		<h2 style=\"text-align:center\">Copyright by Deepak and Astha(IT)</h2>\r\n" + 
				"       </footer>\r\n" + 
				"\r\n" + 
				"	\r\n" + 
				"</body>\r\n" + 
				"</html>");
		}
		catch(Exception e)
		{System.out.println(e);}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
